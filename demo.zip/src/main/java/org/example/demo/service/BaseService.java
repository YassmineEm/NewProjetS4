package org.example.demo.service;

public class BaseService {
    // TODO: Implement BaseService functionality
}
