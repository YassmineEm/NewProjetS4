package org.example.demo.repository;

public class BaseRepository {
    // TODO: Implement BaseRepository functionality
}
