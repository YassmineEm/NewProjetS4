package org.example.demo.model;

public class user {
    // Define entity fields here
}
