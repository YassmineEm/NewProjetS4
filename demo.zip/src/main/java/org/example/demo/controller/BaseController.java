package org.example.demo.controller;

public class BaseController {
    // TODO: Implement BaseController functionality
}
