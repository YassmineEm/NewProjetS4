package org.emma.football.repository;

public class BaseRepository {
    // TODO: Implement BaseRepository functionality
}
