package org.emma.football.controller;

public class BaseController {
    // TODO: Implement BaseController functionality
}
