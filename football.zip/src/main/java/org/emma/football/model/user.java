package org.emma.football.model;

public class user {
    // Define entity fields here
}
