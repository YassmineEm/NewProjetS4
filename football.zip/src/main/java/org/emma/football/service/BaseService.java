package org.emma.football.service;

public class BaseService {
    // TODO: Implement BaseService functionality
}
