package com.example.projet.service;

public class BaseService {
    // TODO: Implement BaseService functionality
}
