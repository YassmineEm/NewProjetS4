package com.example.projet.repository;

public class BaseRepository {
    // TODO: Implement BaseRepository functionality
}
