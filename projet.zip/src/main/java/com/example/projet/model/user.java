package com.example.projet.model;

public class user {
    // Define entity fields here
}
