package com.example.projet.model;

public class note {
    // Define entity fields here
}
