package com.example.projet.controller;

public class BaseController {
    // TODO: Implement BaseController functionality
}
